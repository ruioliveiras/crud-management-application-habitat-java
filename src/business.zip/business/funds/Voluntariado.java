package business.funds;

public interface Voluntariado {
    
    
}